"""
Scanner_Score.py — forward-scores expired Scanner_Live signals against what
actually happened, and tracks rolling expectancy per engine as a decay tripwire.

Why this exists (health check 2026-07-05, revisited 2026-07-25): every metric in
CLAUDE.md so far is in-sample backtest data. The only way to get genuine
out-of-sample evidence is to log signals AS they fire live, wait for them to
play out, and score them against real subsequent price bars. This is that
scoring step — run it periodically (e.g. weekly) alongside Scanner_Live.py.

Flow:
    1. Read ./signals/closed_positions.csv (positions Portfolio.py has archived
       because their hold window elapsed — written by Scanner_Live.py).
    2. For each, pull the ticker's actual daily bars since signal_date and
       replay them exactly like the backtest engines: WIN if target hit before
       stop, LOSS if stop hit first, TIMEOUT if neither within the hold window.
    3. Append newly-scored trades to ./signals/scored_results.csv (idempotent —
       a signal is only ever scored once, keyed on ticker+strategy+signal_date).
    4. Print rolling-20-trade expectancy per engine and flag a decay tripwire
       if it goes negative — this is real forward evidence, not a backtest.

Usage:
    python Scanner_Score.py
"""

import os
import pandas as pd

CLOSED_POSITIONS_PATH = "./signals/closed_positions.csv"
SCORED_RESULTS_PATH   = "./signals/scored_results.csv"
DATA_DIR              = "./data"
TRANSACTION_COST       = 0.0005   # 0.05% each way, matches every backtest engine
ROLLING_WINDOW         = 20       # trades — matches the tripwire agreed 2026-07-05
DECAY_TRIPWIRE_E       = 0.0      # rolling expectancy at/below this % triggers a warning

SCORED_COLUMNS = [
    "ticker", "strategy", "signal_date", "entry", "stop", "target", "rr",
    "expected_exit", "outcome", "exit_price", "exit_date", "net_return",
]


def load_price_data(ticker):
    path = f"{DATA_DIR}/{ticker}_daily.csv"
    if not os.path.exists(path):
        return None
    df = pd.read_csv(path, index_col="Date", parse_dates=True)
    return df


def score_position(pos, price_df):
    """Replay one closed position against actual subsequent bars.
    Mirrors simulate_trades() in the backtest engines: WIN = High touches target
    before Low touches stop; LOSS = stop touched first; TIMEOUT = neither, exit
    at the close of the last available bar in the hold window."""
    window = price_df[(price_df.index > pos["signal_date"]) & (price_df.index <= pos["expected_exit"])]
    if window.empty:
        return None  # data hasn't caught up yet — skip, will retry next run

    outcome, exit_price, exit_date = "TIMEOUT", window["Close"].iloc[-1], window.index[-1]
    for dt, bar in window.iterrows():
        if bar["High"] >= pos["target"]:
            outcome, exit_price, exit_date = "WIN", pos["target"], dt
            break
        if bar["Low"] <= pos["stop"]:
            outcome, exit_price, exit_date = "LOSS", pos["stop"], dt
            break

    net_return = (exit_price - pos["entry"]) / pos["entry"] - 2 * TRANSACTION_COST
    return outcome, round(exit_price, 2), exit_date, round(net_return * 100, 2)


def rolling_expectancy(scored_df, strategy, window=ROLLING_WINDOW):
    sub = scored_df[scored_df["strategy"] == strategy].sort_values("signal_date")
    if sub.empty:
        return None, 0
    recent = sub.tail(window)
    return round(recent["net_return"].mean(), 2), len(recent)


if __name__ == "__main__":
    print(f"\n{'='*62}")
    print("  APEX FORWARD SCORER — scoring live signals against real outcomes")
    print(f"{'='*62}\n")

    if not os.path.exists(CLOSED_POSITIONS_PATH):
        print("  No closed positions yet — nothing has aged past its hold period.")
        print("  Run Scanner_Live.py regularly; positions land here once their hold window elapses.\n")
        raise SystemExit

    closed = pd.read_csv(CLOSED_POSITIONS_PATH, parse_dates=["signal_date", "expected_exit"])
    closed = closed.drop_duplicates(subset=["ticker", "strategy", "signal_date"])

    already_scored = set()
    if os.path.exists(SCORED_RESULTS_PATH):
        prior = pd.read_csv(SCORED_RESULTS_PATH, parse_dates=["signal_date"])
        already_scored = set(zip(prior["ticker"], prior["strategy"], prior["signal_date"]))

    new_scores = []
    price_cache = {}

    for _, pos in closed.iterrows():
        key = (pos["ticker"], pos["strategy"], pos["signal_date"])
        if key in already_scored:
            continue

        if pos["ticker"] not in price_cache:
            price_cache[pos["ticker"]] = load_price_data(pos["ticker"])
        price_df = price_cache[pos["ticker"]]
        if price_df is None:
            print(f"  ⚠️  No price data for {pos['ticker']} — run Scanner_Live.py first")
            continue

        result = score_position(pos, price_df)
        if result is None:
            continue  # not enough bars yet, try again next run
        outcome, exit_price, exit_date, net_return = result

        new_scores.append({
            "ticker": pos["ticker"], "strategy": pos["strategy"], "signal_date": pos["signal_date"],
            "entry": pos["entry"], "stop": pos["stop"], "target": pos["target"], "rr": pos["rr"],
            "expected_exit": pos["expected_exit"], "outcome": outcome, "exit_price": exit_price,
            "exit_date": exit_date, "net_return": net_return,
        })
        icon = "🟢" if net_return > 0 else "🔴"
        print(f"  {icon} {pos['strategy']:12s} {pos['ticker']:6s} signal {pos['signal_date'].date()} "
              f"→ {outcome} {net_return:+.2f}%")

    if new_scores:
        new_df = pd.DataFrame(new_scores)
        header = not os.path.exists(SCORED_RESULTS_PATH)
        new_df.to_csv(SCORED_RESULTS_PATH, mode="a", header=header, index=False)
        print(f"\n  💾 Scored {len(new_scores)} new position(s) -> {SCORED_RESULTS_PATH}")
    else:
        print("\n  No new positions ready to score this run.")

    if os.path.exists(SCORED_RESULTS_PATH):
        all_scored = pd.read_csv(SCORED_RESULTS_PATH, parse_dates=["signal_date"])
        print(f"\n{'─'*62}")
        print(f"  ROLLING {ROLLING_WINDOW}-TRADE EXPECTANCY (live forward evidence, not backtest)")
        print(f"{'─'*62}")
        for strategy in sorted(all_scored["strategy"].unique()):
            e, n = rolling_expectancy(all_scored, strategy)
            if e is None:
                continue
            flag = "🚨 TRIPWIRE — rolling E <= 0, investigate before sizing up" if e <= DECAY_TRIPWIRE_E else "🟢 OK"
            print(f"  {strategy:12s} | rolling E: {e:+.2f}%  (n={n})  {flag}")
        print()
