"""
Portfolio.py — cross-strategy concurrency tracker for APEX.

Problem this solves (health check 2026-07-05): every backtest engine scores each
qualifying signal as an independent trade, but live, Daily/MTF/W3 can all fire on
the same ticker's same pullback at the same time. The backtests show up to 17
correlated single-name tech positions open simultaneously — that is the real
unmanaged risk, not the per-trade win rate.

This module does not touch real orders. It decides which DETECTED signals from
Scanner_Live.py get promoted to "would actually open" under a hard concurrency
cap, and logs every detection (taken or skipped, and why) so paused/skipped
signals can still be forward-scored later by Scanner_Score.py.

Usage:
    from Portfolio import PortfolioTracker
    tracker = PortfolioTracker()
    tagged_df = tracker.process(signals_df, asof=today)   # adds status/reason columns
    tracker.save()
"""

import os
import pandas as pd
from datetime import timedelta

OPEN_POSITIONS_PATH   = "./signals/open_positions.csv"
CLOSED_POSITIONS_PATH = "./signals/closed_positions.csv"   # feeds Scanner_Score.py

# ── CONCURRENCY LIMITS ────────────────────────────────────────────────────────
MAX_CONCURRENT_TOTAL      = 5   # hard cap on simultaneous open positions, all engines/tickers combined.
                                 # Basis: 10% position sizing x 5 = 50% deployed capital ceiling — leaves
                                 # a buffer against the 17-position pile-up flagged in the 2026-07-05 health check.
MAX_CONCURRENT_PER_TICKER = 1   # never let two engines hold the same name at once — this is literally
                                 # the "Daily + MTF + W3 all fire on NVDA" risk flagged 2026-07-05.

# ── ENGINE STATUS (per 2026-07-25 tiered-cull decision) ──────────────────────
# Lower priority number wins the ticker/total-cap tie-break when multiple signals compete for a slot.
ENGINE_PRIORITY = {"W3_SCALPER": 1, "MTF": 2, "DAILY_V11": 3}

# Paused engines are still scanned and logged (so we keep collecting forward evidence on whether they
# recover), but never consume a concurrency slot or get marked "would enter."
PAUSED_ENGINES = {"DAILY_V11"}   # Daily LONG: −0.45% E / 37.5% WR over trailing 12mo — under review, not retired.

# Expected hold period per engine, used only to know when an open position has "expired" and should be
# moved to closed_positions.csv for scoring. Must match each engine's HOLD_DAYS_MAX.
HOLD_DAYS = {"W3_SCALPER": 25, "DAILY_V11": 90, "MTF": 98}

POSITION_COLUMNS = [
    "ticker", "strategy", "signal_date", "entry", "stop", "target", "rr",
    "expected_exit", "status", "reason",
]


class PortfolioTracker:
    """Tracks currently-open (simulated) positions and enforces concurrency caps
    across all APEX engines. One CSV is the source of truth for open positions;
    a second CSV accumulates everything that has aged out, for scoring."""

    def __init__(self, max_total=MAX_CONCURRENT_TOTAL, max_per_ticker=MAX_CONCURRENT_PER_TICKER,
                 open_path=OPEN_POSITIONS_PATH, closed_path=CLOSED_POSITIONS_PATH):
        self.max_total = max_total
        self.max_per_ticker = max_per_ticker
        self.open_path = open_path
        self.closed_path = closed_path
        self.open_positions = self._load(open_path)

    @staticmethod
    def _load(path):
        if os.path.exists(path):
            return pd.read_csv(path, parse_dates=["signal_date", "expected_exit"])
        return pd.DataFrame(columns=POSITION_COLUMNS)

    def _save(self):
        os.makedirs(os.path.dirname(self.open_path), exist_ok=True)
        self.open_positions.to_csv(self.open_path, index=False)

    def _archive_expired(self, asof):
        """Move positions whose hold window has passed into closed_positions.csv.
        This only frees up concurrency slots — it does NOT judge win/loss (that's
        Scanner_Score.py's job, working off real subsequent price data)."""
        if self.open_positions.empty:
            return
        expired_mask = self.open_positions["expected_exit"] <= pd.Timestamp(asof)
        expired = self.open_positions[expired_mask].copy()
        if not expired.empty:
            expired["status"] = "EXPIRED_PENDING_SCORE"
            os.makedirs(os.path.dirname(self.closed_path), exist_ok=True)
            header = not os.path.exists(self.closed_path)
            expired.to_csv(self.closed_path, mode="a", header=header, index=False)
        self.open_positions = self.open_positions[~expired_mask].reset_index(drop=True)

    def process(self, signals_df, asof):
        """
        signals_df: today's detected signals from Scanner_Live.py (must have
            ticker, strategy, signal_date, entry, stop, target, rr).
        asof: today's date.

        Returns signals_df with two new columns:
            status — "TAKEN", "SKIPPED_PAUSED", "SKIPPED_TICKER_CAP", "SKIPPED_TOTAL_CAP", "ALREADY_OPEN"
            reason — human-readable explanation
        Also updates and persists open_positions.csv.
        """
        self._archive_expired(asof)

        df = signals_df.copy()
        df["status"] = ""
        df["reason"] = ""

        already_open_keys = set(
            zip(self.open_positions["ticker"], self.open_positions["strategy"], self.open_positions["signal_date"])
        ) if not self.open_positions.empty else set()

        # Confirmed signals only — pending watchlist entries aren't real positions yet.
        confirmed = df[df["strategy"] != "W3_PENDING"].copy()
        confirmed["signal_date_ts"] = pd.to_datetime(confirmed["signal_date"])

        # Rank: engine priority first (W3 > MTF > Daily), then best R:R, so scarce slots go to the
        # highest-conviction setups when more signals qualify than the cap allows.
        confirmed["_priority"] = confirmed["strategy"].map(ENGINE_PRIORITY).fillna(99)
        confirmed = confirmed.sort_values(["_priority", "rr"], ascending=[True, False])

        # Cap math only counts real (non-paused-shadow) open positions — paused engines are still
        # tracked below so their signals get archived and scored, they just never eat a slot.
        live_open = self.open_positions[self.open_positions.get("status", "OPEN") != "PAUSED_SHADOW"] \
            if not self.open_positions.empty else self.open_positions
        open_count_by_ticker = live_open["ticker"].value_counts().to_dict() if not live_open.empty else {}
        total_open = len(live_open)
        new_rows = []

        for idx, row in confirmed.iterrows():
            key = (row["ticker"], row["strategy"], row["signal_date_ts"])
            if key in already_open_keys:
                df.loc[idx, "status"] = "ALREADY_OPEN"
                df.loc[idx, "reason"] = "Already tracked as an open position"
                continue

            if row["strategy"] in PAUSED_ENGINES:
                hold_days = HOLD_DAYS.get(row["strategy"], 90)
                new_rows.append({
                    "ticker": row["ticker"], "strategy": row["strategy"],
                    "signal_date": row["signal_date_ts"], "entry": row["entry"],
                    "stop": row["stop"], "target": row["target"], "rr": row["rr"],
                    "expected_exit": row["signal_date_ts"] + timedelta(days=hold_days),
                    "status": "PAUSED_SHADOW", "reason": "",
                })
                df.loc[idx, "status"] = "SKIPPED_PAUSED"
                df.loc[idx, "reason"] = f"{row['strategy']} is paused (under review) - tracked as shadow trade for scoring, no capital/slot used"
                continue

            per_ticker_count = open_count_by_ticker.get(row["ticker"], 0)
            if per_ticker_count >= self.max_per_ticker:
                df.loc[idx, "status"] = "SKIPPED_TICKER_CAP"
                df.loc[idx, "reason"] = f"{row['ticker']} already has {per_ticker_count} open position(s) (cap={self.max_per_ticker})"
                continue

            if total_open >= self.max_total:
                df.loc[idx, "status"] = "SKIPPED_TOTAL_CAP"
                df.loc[idx, "reason"] = f"Portfolio at {total_open}/{self.max_total} concurrent positions"
                continue

            hold_days = HOLD_DAYS.get(row["strategy"], 90)
            new_rows.append({
                "ticker": row["ticker"], "strategy": row["strategy"],
                "signal_date": row["signal_date_ts"], "entry": row["entry"],
                "stop": row["stop"], "target": row["target"], "rr": row["rr"],
                "expected_exit": row["signal_date_ts"] + timedelta(days=hold_days),
                "status": "OPEN", "reason": "",
            })
            df.loc[idx, "status"] = "TAKEN"
            df.loc[idx, "reason"] = f"Opened - {total_open + 1}/{self.max_total} total, {per_ticker_count + 1}/{self.max_per_ticker} on {row['ticker']}"
            total_open += 1
            open_count_by_ticker[row["ticker"]] = per_ticker_count + 1

        # Pending watchlist rows are informational only — mark them and pass through untouched.
        df.loc[df["strategy"] == "W3_PENDING", "status"] = "WATCHLIST"
        df.loc[df["strategy"] == "W3_PENDING", "reason"] = "Breakout not yet confirmed"

        if new_rows:
            self.open_positions = pd.concat([self.open_positions, pd.DataFrame(new_rows)], ignore_index=True)
            self._save()
        elif not self.open_positions.empty:
            self._save()  # persist any archiving that happened even if nothing new opened

        return df.drop(columns=["signal_date_ts", "_priority"], errors="ignore")

    def summary(self):
        if self.open_positions.empty:
            return f"0/{self.max_total} open"
        live = self.open_positions[self.open_positions["status"] != "PAUSED_SHADOW"]
        shadow = self.open_positions[self.open_positions["status"] == "PAUSED_SHADOW"]
        parts = ", ".join(f"{k}:{v}" for k, v in live["strategy"].value_counts().to_dict().items())
        msg = f"{len(live)}/{self.max_total} open ({parts})" if parts else f"{len(live)}/{self.max_total} open"
        if not shadow.empty:
            shadow_parts = ", ".join(f"{k}:{v}" for k, v in shadow["strategy"].value_counts().to_dict().items())
            msg += f"  |  paused-shadow (no slot used): {shadow_parts}"
        return msg
