"""
Dashboard.py — APEX portfolio monitoring dashboard (local, live).

Reads the same CSVs the rest of APEX already produces — nothing here recomputes
strategy logic, it only visualizes what Backtest_*.py / Scanner_Live.py /
Portfolio.py / Scanner_Score.py already wrote to disk.

Visual system: fixed categorical hue per engine (never reassigned by rank/filter),
green/red reserved exclusively for gain/loss + bullish/bearish status — never
reused as a series color. Both a light and dark step exist for every role
(dataviz design skill palette); an in-app toggle next to the title switches
everything built in this file (cards, pills, Plotly charts). It does NOT change
Streamlit's own native chrome (dataframe grid, tab underline) — that's fixed
once at process start by .streamlit/config.toml, and this app's native "⋮" menu
has no Settings/theme entry to unify with (verified 2026-07-26 — it's not there).

Theme-color implementation note: every themed element renders its colors as
INLINE styles computed fresh from the current COLORS dict on each Streamlit
rerun — not a shared <style> block with interpolated values. This is deliberate:
an earlier version used one injected stylesheet whose hex content changed across
reruns, and it rendered inconsistently (verified via headless testing that the
generated CSS was always correct, so the mismatch was in how the browser
applied a mutating stylesheet, not in the Python logic). Inline styles have no
shared-stylesheet-staleness failure mode by construction. The only <style>
block left is fully static — same text on every render — for layout rules that
never depend on theme (padding, radius, font).

Sections:
  1. Regime header + KPI strip — regime, VIX, concurrency, blended active
     expectancy, best-performing active engine — the "at a glance" row
  2. Portfolio scorecard  — concurrency usage, open positions, per-engine status
                            with a rolling-expectancy sparkline per engine
  3. Expectancy trend     — rolling expectancy per engine, backtest history +
                            real forward evidence (starts empty — expected)
  4. Signal feed          — the latest Scanner_Live.py run, as cards
  5. Watchlist            — all tracked tickers, last price, 1-day %, 20-day
                            sparkline — fast, local-data-only, no news calls
  6. Ticker Chart & News  — price with entry/stop/target overlay, headlines,
                            and a News Impact starting point (headline volume +
                            observed price reaction after each headline)

Run:  streamlit run Dashboard.py
"""

import os
import glob

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st
import yfinance as yf

DATA_DIR    = "./data"
SIGNALS_DIR = "./signals"
RESULTS_DIR = "./results"

# Mirrors Portfolio.py — kept as a plain constant here so this file has no import
# dependency on the live scanner stack; update both if the tiering changes.
PAUSED_ENGINES  = {"Daily LONG"}
MAX_CONCURRENT_TOTAL = 5
MAX_CONCURRENT_PER_TICKER = 1
VIX_BLOCK_LEVEL = 25  # matches Backtest_W3_Scalper.py's regime gate

ENGINES = {
    # label: (backtest CSV, entry-date column, optional direction filter)
    "Daily LONG": (f"{RESULTS_DIR}/ALL_backtest.csv", "confirm_date", ("direction", "LONG")),
    "MTF":        (f"{RESULTS_DIR}/mtf/ALL_mtf_backtest.csv", "confirm_ts_4h", None),
    "W3 Scalper": (f"{RESULTS_DIR}/w3_scalper/ALL_w3_scalper.csv", "w3_break_date", None),
}

# ── COLOR SYSTEM (dataviz skill palette, dark — dark-only by deliberate decision,
# see render_title_theme_and_refresh) ───────────────────────────────────────────
# Fixed categorical slots (blue/orange/aqua — the validated first-3 all-pairs-safe
# subset). Identity follows the entity, never rank: these never change per filter.
ENGINE_COLOR = {"dark": {"W3 Scalper": "#3987e5", "MTF": "#d95926", "Daily LONG": "#199e70"}}

# Status palette — reserved, mode-invariant. Never reused as a series/entity color.
GOOD, WARNING, SERIOUS, CRITICAL, MUTED = "#0ca30c", "#fab219", "#ec835a", "#d03b3b", "#898781"
STATUS_HEX = {"good": GOOD, "warning": WARNING, "serious": SERIOUS, "critical": CRITICAL, "muted": MUTED}

THEMES = {
    "dark": dict(
        page="#0d0d0d", surface="#1a1a19", ink_primary="#ffffff", ink_secondary="#c3c2b7",
        muted="#898781", gridline="#2c2c2a", baseline="#383835", border="rgba(255,255,255,0.10)",
    ),
}

COLORS = dict(THEMES["dark"])
ENGINE_ACCENT = dict(ENGINE_COLOR["dark"])

st.set_page_config(page_title="APEX Dashboard", layout="wide", page_icon="📈")


def render_title_theme_and_refresh():
    """Dark-only — decided with the user 2026-07-26, not for them. Native widgets
    (dropdowns, dataframes) read their color from .streamlit/config.toml once at
    process start and cannot change at runtime; there's no native Settings/theme
    entry in this app's "⋮" menu to unify with either. A toggle could therefore
    only ever flip the custom cards/charts, never the whole page — a hard platform
    ceiling, not a bug to keep patching. Given that constraint stated plainly, the
    call was to commit to one deliberately-designed dark theme everywhere instead —
    which is also just how Robinhood/TradingView actually ship."""
    COLORS.update(THEMES["dark"])
    ENGINE_ACCENT.update(ENGINE_COLOR["dark"])

    title_col, refresh_col = st.columns([7, 1], vertical_alignment="center")
    with title_col:
        st.title("📈 APEX Dashboard")
        st.caption("Local, reads the same CSVs Backtest_*.py / Scanner_Live.py / Portfolio.py / Scanner_Score.py already produce.")
    with refresh_col:
        if st.button("🔄 Refresh", help="Clears cached data and re-pulls from disk/yfinance now, instead of waiting for the cache to expire (5-30 min depending on source).", width='stretch'):
            st.cache_data.clear()
            st.rerun()
    return "dark"


def inject_css():
    """Fully static — identical text every render, so it has no shared-stylesheet-
    staleness failure mode. Only theme-INVARIANT rules live here: layout, spacing,
    font, motion, and the status-pill color classes (good/warning/serious/critical/
    muted are the same hex in both light and dark per the palette, so they're safe
    as classes). Anything that actually differs between light/dark is inline-styled
    at the call site instead — see stat_card() / pill()."""
    st.markdown(f"""
    <style>
    html, body, [class*="css"] {{ font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }}

    [data-testid="stAppViewContainer"] {{ background: #0d0d0d; }}

    .apex-card {{
        border-radius: 14px; padding: 16px 20px; margin-bottom: 10px;
        transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
    }}
    .apex-card:hover {{ transform: translateY(-2px); border-color: rgba(255,255,255,0.20); }}
    .apex-label {{ font-size: 0.76rem; text-transform: uppercase; letter-spacing: 0.07em; margin-bottom: 5px; font-weight: 600; }}
    .apex-value {{ font-size: 2rem; font-weight: 700; line-height: 1.1; letter-spacing: -0.02em; }}
    .apex-sub   {{ font-size: 0.82rem; margin-top: 5px; }}

    .apex-pill {{
        display: inline-flex; align-items: center; gap: 5px;
        padding: 3px 11px; border-radius: 999px; font-size: 0.76rem; font-weight: 700;
        letter-spacing: 0.02em;
    }}
    .pill-good     {{ background: rgba(12,163,12,0.16);  color: {GOOD}; }}
    .pill-warning  {{ background: rgba(250,178,25,0.18); color: {WARNING}; }}
    .pill-serious  {{ background: rgba(236,131,90,0.18); color: {SERIOUS}; }}
    .pill-critical {{ background: rgba(208,59,59,0.16);  color: {CRITICAL}; }}
    .pill-muted    {{ background: rgba(137,135,129,0.18); color: {MUTED}; }}

    .apex-news-title {{ font-weight: 500; text-decoration: none; }}
    .apex-news-meta  {{ font-size: 0.78rem; }}

    /* Native widget polish — safe as a static, permanent stylesheet now that there's
    exactly one theme (no toggle-driven content changes to risk going stale). */
    [data-testid="stTabs"] button[aria-selected="true"] p {{ color: #3987e5 !important; }}
    [data-testid="stTabs"] [data-baseweb="tab-highlight"] {{ background-color: #3987e5 !important; }}
    [data-testid="stButton"] button, [data-testid="stDownloadButton"] button {{
        border-radius: 10px; border: 1px solid rgba(255,255,255,0.14);
        transition: border-color 0.15s ease, transform 0.15s ease;
    }}
    [data-testid="stButton"] button:hover, [data-testid="stDownloadButton"] button:hover {{
        border-color: #3987e5; transform: translateY(-1px);
    }}
    [data-testid="stDataFrame"], [data-testid="stExpander"] {{ border-radius: 12px; overflow: hidden; }}
    </style>
    """, unsafe_allow_html=True)


def pill(text, kind="muted"):
    return f'<span class="apex-pill pill-{kind}">{text}</span>'


def stat_card(label, value, sub=None, accent_hex=None, value_color=None):
    """Colors are inline (computed fresh from the current COLORS dict each call) —
    deliberately not a CSS class, so this card can never show a stale theme.
    Flat solid surface, no gradient sweep — Robinhood/modern-dashboard cards are
    flat with a confident shadow, not a visible diagonal "shine" (that read as
    dated/tacky, correctly). Engine cards get a subtle matching glow instead."""
    accent_style = f"border-left: 3px solid {accent_hex};" if accent_hex else ""
    glow = f", 0 0 18px {_to_rgba(accent_hex, 0.10)}" if accent_hex else ""
    value_style = f"color:{value_color};" if value_color else f"color:{COLORS['ink_primary']};"
    sub_html = f'<div class="apex-sub" style="color:{COLORS["muted"]};">{sub}</div>' if sub else ""
    st.markdown(f"""
    <div class="apex-card" style="background:{COLORS['surface']}; border:1px solid {COLORS['border']}; {accent_style}
         box-shadow: 0 4px 16px rgba(0,0,0,0.30){glow};">
        <div class="apex-label" style="color:{COLORS['ink_secondary']};">{label}</div>
        <div class="apex-value" style="{value_style}">{value}</div>
        {sub_html}
    </div>
    """, unsafe_allow_html=True)


def base_layout(fig, height=420, top_margin=40, legend_y=1.02):
    fig.update_layout(
        height=height,
        paper_bgcolor=COLORS['surface'], plot_bgcolor=COLORS['surface'],
        font=dict(color=COLORS['ink_secondary'], family="system-ui, -apple-system, Segoe UI, sans-serif"),
        legend=dict(orientation="h", yanchor="bottom", y=legend_y, bgcolor="rgba(0,0,0,0)"),
        margin=dict(l=10, r=10, t=top_margin, b=10),
        hovermode="x unified",
    )
    fig.update_xaxes(gridcolor=COLORS['gridline'], zerolinecolor=COLORS['baseline'], showline=True, linecolor=COLORS['baseline'])
    fig.update_yaxes(gridcolor=COLORS['gridline'], zerolinecolor=COLORS['baseline'], showline=False)
    return fig


def _to_rgba(hex_color, alpha):
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def sparkline_fig(series, color):
    fig = go.Figure(go.Scatter(
        x=list(range(len(series))), y=series.values, mode="lines",
        line=dict(color=color, width=2), fill="tozeroy", fillcolor=_to_rgba(color, 0.12),
    ))
    fig.update_layout(
        height=50, margin=dict(l=0, r=0, t=0, b=0),
        xaxis=dict(visible=False), yaxis=dict(visible=False),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", showlegend=False,
    )
    return fig


# ── DATA LOADERS ───────────────────────────────────────────────────────────────

@st.cache_data(ttl=300)
def load_regime():
    """QQQ close vs 50-day MA — same gate Scanner_Live.py uses. Drops the trailing
    NaN-OHLC bar yfinance sometimes returns for an unsettled session (the bug fixed
    in Scanner_Live.py's load_data on 2026-07-25)."""
    path = f"{DATA_DIR}/QQQ_daily.csv"
    if not os.path.exists(path):
        return None
    df = pd.read_csv(path, index_col="Date", parse_dates=True)
    df = df.dropna(subset=["Open", "High", "Low", "Close"])
    if df.empty:
        return None
    df["MA50"] = df["Close"].rolling(50).mean()
    last = df.iloc[-1]
    return {
        "date": df.index[-1], "close": last["Close"], "ma50": last["MA50"],
        "bullish": bool(last["Close"] > last["MA50"]),
    }


@st.cache_data(ttl=300)
def load_vix():
    try:
        d = yf.download("^VIX", period="3mo", interval="1d", auto_adjust=True, progress=False)
        if isinstance(d.columns, pd.MultiIndex):
            d.columns = d.columns.get_level_values(0)
        close = d["Close"].dropna()
        return float(close.iloc[-1]) if not close.empty else None
    except Exception:
        return None


@st.cache_data(ttl=300)
def load_backtest_trades(engine):
    path, date_col, direction_filter = ENGINES[engine]
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_csv(path)
    if direction_filter is not None:
        col, val = direction_filter
        df = df[df[col] == val]
    df["entry_date"] = pd.to_datetime(df[date_col])
    return df.sort_values("entry_date")


def win_rate(df):
    return df["outcome"].isin(["WIN", "PARTIAL_WIN"]).mean() * 100 if len(df) else 0.0


def recency_split(df, window_days=365):
    """First-half / second-half / trailing-window expectancy — same split used in
    the 2026-07-25 tiered-cull analysis, computed live instead of hardcoded."""
    if df.empty:
        return None
    half = len(df) // 2
    first, second = df.iloc[:half], df.iloc[half:]
    cutoff = df["entry_date"].max() - pd.Timedelta(days=window_days)
    recent = df[df["entry_date"] >= cutoff]
    return {
        "first_half":  {"e": first["net_return"].mean(), "wr": win_rate(first), "n": len(first)},
        "second_half": {"e": second["net_return"].mean(), "wr": win_rate(second), "n": len(second)},
        "recent":      {"e": recent["net_return"].mean(), "wr": win_rate(recent), "n": len(recent)},
    }


def rolling_expectancy_series(df, window=15):
    if df.empty:
        return pd.Series(dtype=float)
    return df.set_index("entry_date")["net_return"].rolling(window, min_periods=5).mean()


def blended_active_expectancy():
    """Sample-weighted trailing-12mo expectancy across non-paused engines only,
    plus whichever active engine currently leads — feeds the KPI strip."""
    total_e_n, total_n, best = 0.0, 0, None
    for engine in ENGINES:
        if engine in PAUSED_ENGINES:
            continue
        split = recency_split(load_backtest_trades(engine))
        if split is None or split["recent"]["n"] == 0:
            continue
        r = split["recent"]
        total_e_n += r["e"] * r["n"]
        total_n += r["n"]
        if best is None or r["e"] > best[1]:
            best = (engine, r["e"])
    blended = total_e_n / total_n if total_n else None
    return blended, total_n, best


def load_open_positions():
    path = f"{SIGNALS_DIR}/open_positions.csv"
    if not os.path.exists(path):
        return pd.DataFrame()
    return pd.read_csv(path, parse_dates=["signal_date", "expected_exit"])


def load_scored_results():
    path = f"{SIGNALS_DIR}/scored_results.csv"
    if not os.path.exists(path):
        return pd.DataFrame()
    return pd.read_csv(path, parse_dates=["signal_date", "exit_date"])


def load_latest_signals():
    files = sorted(glob.glob(f"{SIGNALS_DIR}/signals_*.csv"))
    if not files:
        return None, pd.DataFrame()
    latest = files[-1]
    return latest, pd.read_csv(latest)


@st.cache_data(ttl=300)
def load_price(ticker):
    path = f"{DATA_DIR}/{ticker}_daily.csv"
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_csv(path, index_col="Date", parse_dates=True)
    return df.dropna(subset=["Open", "High", "Low", "Close"])


@st.cache_data(ttl=1800)
def load_news(ticker, limit=6):
    try:
        items = yf.Ticker(ticker).news or []
    except Exception:
        return []
    out = []
    for n in items[:limit]:
        c = n.get("content", {})
        link = (c.get("canonicalUrl") or {}).get("url") or (c.get("clickThroughUrl") or {}).get("url")
        out.append({
            "title": c.get("title", ""),
            "provider": (c.get("provider") or {}).get("displayName", ""),
            "pub_date": c.get("pubDate", ""),
            "url": link,
        })
    return out


@st.cache_data(ttl=86400)
def load_company_name(ticker):
    try:
        info = yf.Ticker(ticker).info
        return info.get("shortName") or info.get("longName") or ticker
    except Exception:
        return ticker


def is_relevant(title, ticker, company_name):
    """Crude but honest relevance check — yfinance's per-ticker .news often includes
    broad market coverage loosely bucketed under a ticker's feed, not stories actually
    about that company. Flag rather than silently hide, so nothing looks like it
    vanished."""
    t = title.lower()
    if ticker.lower() in t:
        return True
    if company_name and company_name != ticker:
        first_word = company_name.split()[0].lower()
        if len(first_word) > 2 and first_word in t:
            return True
    return False


def move_vs_normal(price):
    """Today's move against the stock's own trailing 20-day typical daily move —
    a same-ticker, self-relative baseline, not a market-wide comparison."""
    if price.empty or len(price) < 21:
        return None, None, None
    today_move = float((price["Close"].iloc[-1] / price["Close"].iloc[-2] - 1) * 100)
    typical = float(price["Close"].pct_change().abs().tail(20).mean() * 100)
    ratio = abs(today_move) / typical if typical > 0 else None
    return today_move, typical, ratio


def _parse_pubdate(s):
    try:
        ts = pd.Timestamp(s)
        if ts.tzinfo is not None:
            ts = ts.tz_convert("UTC").tz_localize(None)
        return ts
    except Exception:
        return None


def universe():
    files = glob.glob(f"{DATA_DIR}/*_daily.csv")
    tickers = sorted({os.path.basename(f).replace("_daily.csv", "") for f in files} - {"QQQ", "SPY"})
    return tickers


# ── SECTIONS ───────────────────────────────────────────────────────────────────

def render_kpi_strip():
    regime = load_regime()
    vix = load_vix()
    open_pos = load_open_positions()
    live = open_pos[open_pos["status"] != "PAUSED_SHADOW"] if not open_pos.empty else open_pos
    blended, n, best = blended_active_expectancy()

    cols = st.columns(5)
    with cols[0]:
        if regime:
            kind = "good" if regime["bullish"] else "critical"
            stat_card(f"Regime (QQQ) · {regime['date'].strftime('%Y-%m-%d')}",
                      pill(("▲ BULLISH" if regime["bullish"] else "▼ BEARISH"), kind),
                      sub=f"${regime['close']:.2f} vs MA50 ${regime['ma50']:.2f}")
        else:
            stat_card("Regime (QQQ)", "—", sub="No data — run Scanner_Live.py")
    with cols[1]:
        if vix is not None:
            vkind = "critical" if vix >= VIX_BLOCK_LEVEL else "warning" if vix >= 20 else "good"
            stat_card("VIX", f"{vix:.1f}", sub=f"Block level {VIX_BLOCK_LEVEL} (W3 gate)", value_color=STATUS_HEX[vkind])
        else:
            stat_card("VIX", "—")
    with cols[2]:
        used = len(live) if not open_pos.empty else 0
        cap_kind = "critical" if used >= MAX_CONCURRENT_TOTAL else "warning" if used >= MAX_CONCURRENT_TOTAL - 1 else "good"
        stat_card("Concurrency", pill(f"{used}/{MAX_CONCURRENT_TOTAL}", cap_kind))
    with cols[3]:
        if blended is not None:
            stat_card("Blended active E/trade", f"{blended:+.2f}%", sub=f"n={n} · W3+MTF only, 📌 in-sample",
                       value_color=GOOD if blended > 0 else CRITICAL)
        else:
            stat_card("Blended active E/trade", "—")
    with cols[4]:
        if best:
            stat_card("Best active engine", best[0], sub=f"{best[1]:+.2f}%/trade trailing 12mo")
        else:
            stat_card("Best active engine", "—")


def render_scorecard():
    st.subheader("Portfolio scorecard")
    open_pos = load_open_positions()

    if open_pos.empty:
        st.info("No open positions tracked yet — this fills in once Scanner_Live.py finds a signal that clears the concurrency cap.")
    else:
        live = open_pos[open_pos["status"] != "PAUSED_SHADOW"]
        shadow = open_pos[open_pos["status"] == "PAUSED_SHADOW"]
        c1, c2, c3 = st.columns(3)
        with c1:
            cap_kind = "critical" if len(live) >= MAX_CONCURRENT_TOTAL else "warning" if len(live) >= MAX_CONCURRENT_TOTAL - 1 else "good"
            stat_card("Concurrency used", pill(f"{len(live)}/{MAX_CONCURRENT_TOTAL}", cap_kind))
        with c2:
            stat_card("Tickers open", str(live["ticker"].nunique()))
        with c3:
            stat_card("Paused-shadow (no slot used)", str(len(shadow)), sub="Tracked for scoring only")
        st.dataframe(
            open_pos[["ticker", "strategy", "signal_date", "entry", "stop", "target", "rr", "expected_exit", "status"]],
            width='stretch', hide_index=True,
        )

    st.markdown("#### Per-engine status")
    st.caption("🔶 Backtest = in-sample history, recomputed live from results/*.csv. 🟢 Live forward = real scored signals from Scanner_Score.py.")
    scored = load_scored_results()
    cols = st.columns(len(ENGINES))
    for col, engine in zip(cols, ENGINES):
        with col:
            accent = ENGINE_ACCENT[engine]
            bt = load_backtest_trades(engine)
            split = recency_split(bt)

            status_pill = pill("⛔ PAUSED", "serious") if engine in PAUSED_ENGINES else pill("● ACTIVE", "good")
            st.markdown(f'<div style="margin-bottom:6px;"><b>{engine}</b> &nbsp; {status_pill}</div>', unsafe_allow_html=True)

            if split is None:
                stat_card("Backtest, trailing 12mo", "—", sub="No backtest results found.", accent_hex=accent)
                continue

            r = split["recent"]
            stat_card(
                "Backtest, trailing 12mo E/trade",
                f"{r['e']:+.2f}%",
                sub=f"n={r['n']} &middot; WR {r['wr']:.0f}% &middot; 📌 in-sample",
                accent_hex=accent,
                value_color=GOOD if r["e"] > 0 else CRITICAL,
            )

            spark = rolling_expectancy_series(bt).dropna().tail(30)
            if len(spark) >= 2:
                st.plotly_chart(sparkline_fig(spark, ENGINE_ACCENT[engine]), width='stretch',
                                 config={"displayModeBar": False}, key=f"spark_{engine}")

            engine_key = engine.upper().replace(" ", "_")
            scored_e = scored[scored["strategy"] == engine_key] if not scored.empty else pd.DataFrame()
            if not scored_e.empty:
                e = scored_e["net_return"].mean()
                stat_card("Live forward E/trade", f"{e:+.2f}%", sub=f"n={len(scored_e)} &middot; 🟢 real signals",
                           accent_hex=accent, value_color=GOOD if e > 0 else CRITICAL)
            else:
                st.caption("No live forward trades scored yet.")


def render_expectancy_trend():
    st.subheader("Expectancy trend — rolling 15-trade average")
    st.caption("Solid = backtest history (in-sample). Dashed + markers = live forward evidence from Scanner_Score.py — starts empty, that's expected, not a bug.")

    fig = go.Figure()
    any_data = False
    for engine in ENGINES:
        color = ENGINE_ACCENT[engine]
        series = rolling_expectancy_series(load_backtest_trades(engine))
        if series.empty:
            continue
        any_data = True
        # Glow pass: a wider, near-transparent line under the crisp one — pure polish,
        # no data meaning, drawn first so the real line sits on top of it.
        fig.add_trace(go.Scatter(
            x=series.index, y=series.values, mode="lines", line=dict(color=color, width=8),
            opacity=0.12, legendgroup=engine, showlegend=False, hoverinfo="skip",
        ))
        fig.add_trace(go.Scatter(
            x=series.index, y=series.values, mode="lines", name=engine,
            line=dict(color=color, width=2), fill="tozeroy", fillcolor=_to_rgba(color, 0.10),
            legendgroup=engine,
        ))
        fig.add_annotation(x=series.index[-1], y=series.values[-1], text=f"{series.values[-1]:+.1f}%",
                            showarrow=False, xanchor="left", xshift=8, font=dict(color=color, size=12))

    scored = load_scored_results()
    if not scored.empty:
        for engine in ENGINES:
            key = engine.upper().replace(" ", "_")
            sub = scored[scored["strategy"] == key].sort_values("signal_date")
            if sub.empty:
                continue
            series = sub.set_index("signal_date")["net_return"].rolling(15, min_periods=3).mean()
            fig.add_trace(go.Scatter(
                x=series.index, y=series.values, mode="lines+markers", name=f"{engine} (live)",
                line=dict(color=ENGINE_ACCENT[engine], dash="dash", width=2),
                marker=dict(size=8, line=dict(width=2, color=COLORS['surface'])),
                legendgroup=engine,
            ))

    fig.add_hline(y=0, line_width=1, line_color=COLORS['baseline'])
    fig.update_layout(xaxis_title=None, yaxis_title="Rolling avg net return (%)", showlegend=True)
    fig = base_layout(fig, height=440)
    if any_data:
        st.plotly_chart(fig, width='stretch')
    else:
        st.info("No backtest result CSVs found in ./results — run a backtest engine first.")


def render_signal_feed():
    st.subheader("Latest signal feed")
    latest_path, df_sig = load_latest_signals()
    if df_sig.empty:
        st.info("No signals logged yet — run `python Scanner_Live.py` to generate today's scan.")
        return
    st.caption(f"From {os.path.basename(latest_path)}")
    if "status" in df_sig.columns:
        taken = df_sig[df_sig["status"] == "TAKEN"]
        skipped = df_sig[df_sig["status"].isin(
            ["SKIPPED_PAUSED", "SKIPPED_TICKER_CAP", "SKIPPED_TOTAL_CAP", "ALREADY_OPEN"])]
        watch = df_sig[df_sig["status"] == "WATCHLIST"]

        c1, c2, c3 = st.columns(3)
        with c1: stat_card("Would enter", pill(str(len(taken)), "good"))
        with c2: stat_card("Skipped (cap/paused)", pill(str(len(skipped)), "muted"))
        with c3: stat_card("Watchlist", pill(str(len(watch)), "warning"))

        t1, t2, t3 = st.tabs([f"Would enter ({len(taken)})", f"Skipped ({len(skipped)})", f"Watchlist ({len(watch)})"])
        with t1: st.dataframe(taken, width='stretch', hide_index=True)
        with t2: st.dataframe(skipped, width='stretch', hide_index=True)
        with t3: st.dataframe(watch, width='stretch', hide_index=True)
    else:
        st.dataframe(df_sig, width='stretch', hide_index=True)


def render_watchlist():
    st.subheader("Watchlist")
    st.caption("Local price data only — fast, no news calls. Click a row to load it into 'Ticker Chart & News'.")
    rows = []
    for t in universe():
        df = load_price(t)
        if len(df) < 11:
            continue
        last, prev = df["Close"].iloc[-1], df["Close"].iloc[-2]
        chg = (last / prev - 1) * 100
        rows.append({"Ticker": t, "Last": round(float(last), 2), "1D %": round(float(chg), 2),
                     "Trend (20d)": df["Close"].tail(20).tolist()})
    if not rows:
        st.info("No cached price data yet — run Yfinancedata.py or Scanner_Live.py first.")
        return

    fc1, fc2 = st.columns([2, 1])
    with fc1:
        query = st.text_input("Search ticker", "", placeholder="e.g. NVDA").strip().upper()
    with fc2:
        move_filter = st.selectbox("Show", ["All", "Gainers", "Losers"])

    wdf = pd.DataFrame(rows)
    if query:
        wdf = wdf[wdf["Ticker"].str.contains(query)]
    if move_filter == "Gainers":
        wdf = wdf[wdf["1D %"] > 0]
    elif move_filter == "Losers":
        wdf = wdf[wdf["1D %"] < 0]
    wdf = wdf.sort_values("1D %", ascending=False)

    if wdf.empty:
        st.caption("No tickers match this filter.")
    else:
        wdf = wdf.reset_index(drop=True)
        event = st.dataframe(
            wdf, width='stretch', hide_index=True,
            on_select="rerun", selection_mode="single-row",
            column_config={
                "Last": st.column_config.NumberColumn(format="$%.2f"),
                "1D %": st.column_config.NumberColumn(format="%.2f%%"),
                "Trend (20d)": st.column_config.LineChartColumn(width="medium"),
            },
        )
        selected_rows = event.selection.rows if hasattr(event, "selection") else []
        if selected_rows:
            picked = wdf.iloc[selected_rows[0]]["Ticker"]
            st.session_state.selected_ticker = picked
            st.success(f"📌 {picked} loaded — switch to the 'Ticker Chart & News' tab to view it.")

        csv = wdf.drop(columns=["Trend (20d)"]).to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download watchlist CSV", csv, file_name="apex_watchlist.csv", mime="text/csv")


def engines_with_trade(ticker):
    return [e for e in ENGINES
            if not load_backtest_trades(e).empty
            and "ticker" in load_backtest_trades(e).columns
            and ticker in load_backtest_trades(e)["ticker"].values]


def render_ticker_chart(ticker):
    df = load_price(ticker)
    if df.empty:
        st.warning(f"No price data cached for {ticker} — run Yfinancedata.py or Scanner_Live.py first.")
        return

    df = df.tail(400).copy()
    df["MA50"] = df["Close"].rolling(50).mean()
    has_volume = "Volume" in df.columns and df["Volume"].sum() > 0

    # Overlay one engine's most recent backtested trade at a time — up to 9 lines from
    # 3 stacked engines is noise, not signal. Defaults to the primary engine if it has one.
    candidates = engines_with_trade(ticker)
    options = ["None"] + candidates
    default_idx = options.index("W3 Scalper") if "W3 Scalper" in candidates else (1 if candidates else 0)
    overlay_choice = st.radio("Show last backtested setup from", options, index=default_idx,
                               horizontal=True, key=f"overlay_{ticker}")

    rows_spec = [0.72, 0.28] if has_volume else [1.0]
    fig = make_subplots(rows=len(rows_spec), cols=1, shared_xaxes=True,
                        row_heights=rows_spec, vertical_spacing=0.03)

    fig.add_trace(go.Candlestick(
        x=df.index, open=df["Open"], high=df["High"], low=df["Low"], close=df["Close"],
        name=ticker, increasing_line_color=GOOD, decreasing_line_color=CRITICAL,
        increasing_fillcolor=GOOD, decreasing_fillcolor=CRITICAL,
    ), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index, y=df["MA50"], mode="lines", name="MA50",
                              line=dict(color=COLORS['ink_secondary'], width=1.5, dash="dot")), row=1, col=1)

    if overlay_choice != "None":
        bt = load_backtest_trades(overlay_choice)
        trade_rows = bt[bt["ticker"] == ticker].sort_values("entry_date")
        if not trade_rows.empty:
            last = trade_rows.iloc[-1]
            entry, stop = last.get("entry_price"), last.get("stop_price")
            target = last.get("target_1_price") or last.get("target_price")
            if not pd.isna(entry):
                # Legend entries with the value baked into the name, not edge annotations —
                # annotation text at the plot edge was getting clipped and unreadable
                # (screenshot showed "Ta", "En", "St"). The legend has room and never clips.
                x_span = [df.index.min(), df.index.max()]
                for y, label, color in [(target, "Target", GOOD),
                                         (entry, "Entry", ENGINE_ACCENT[overlay_choice]),
                                         (stop, "Stop", CRITICAL)]:
                    if y is not None and not pd.isna(y):
                        fig.add_trace(go.Scatter(
                            x=x_span, y=[y, y], mode="lines",
                            line=dict(color=color, width=1.5, dash="dash"),
                            name=f"{label}: ${y:.2f}", hoverinfo="name",
                        ), row=1, col=1)
            st.caption(f"{overlay_choice}'s most recent {ticker} backtest trade — see the chart legend for exact "
                       f"entry/stop/target levels. Historical, not a live signal.")

    if has_volume:
        vol_colors = [GOOD if c >= o else CRITICAL for o, c in zip(df["Open"], df["Close"])]
        fig.add_trace(go.Bar(x=df.index, y=df["Volume"], marker_color=vol_colors,
                              marker_line_width=0, opacity=0.55, name="Volume", showlegend=False),
                      row=2, col=1)

    # Range-selector buttons sit ABOVE the legend (y=1.18 vs legend's 1.02) with enough top
    # margin for both rows — they were previously overlapping (unreadable, per screenshot).
    fig.update_xaxes(
        rangeselector=dict(
            y=1.18, yanchor="bottom", x=0, xanchor="left",
            buttons=[
                dict(count=1, label="1M", step="month", stepmode="backward"),
                dict(count=3, label="3M", step="month", stepmode="backward"),
                dict(count=6, label="6M", step="month", stepmode="backward"),
                dict(count=1, label="1Y", step="year", stepmode="backward"),
                dict(step="all", label="All"),
            ],
            bgcolor=COLORS['surface'], activecolor=ENGINE_ACCENT["W3 Scalper"],
            font=dict(color=COLORS['ink_primary'], size=11),
        ),
        rangeslider_visible=False, row=1, col=1,
    )
    fig.update_layout(showlegend=True)
    fig = base_layout(fig, height=600 if has_volume else 520, top_margin=95)
    st.plotly_chart(fig, width='stretch')


def render_news_and_impact(ticker):
    st.markdown(f"#### News impact — {ticker}")
    company = load_company_name(ticker)
    items = load_news(ticker)
    price = load_price(ticker)
    dated = [(n, _parse_pubdate(n["pub_date"])) for n in items]

    recent_cutoff = pd.Timestamp.now() - pd.Timedelta(days=3)
    recent_count = sum(1 for _, d in dated if d is not None and d >= recent_cutoff)
    relevant_recent = [n for n, d in dated
                       if d is not None and d >= recent_cutoff and is_relevant(n["title"], ticker, company)]
    today_move, typical, ratio = move_vs_normal(price)

    # ── The one clear verdict, computed by an explicit, inspectable rule (see expander below) ──
    if len(relevant_recent) >= 2 and ratio is not None and ratio >= 1.5:
        vkind, vicon, vtext = "critical", "🔴", "News-driven activity likely"
    elif (len(relevant_recent) >= 1 and ratio is not None and ratio >= 1.2) or len(relevant_recent) >= 3:
        vkind, vicon, vtext = "warning", "🟡", "Some signal, not conclusive"
    else:
        vkind, vicon, vtext = "good", "🟢", "No unusual news-driven activity detected"

    ratio_txt = f"a {ratio:.1f}x move vs its own typical day" if ratio is not None else "no move data available"
    st.markdown(f"""
    <div class="apex-card" style="background:{COLORS['surface']}; border:1px solid {COLORS['border']};
         border-left:4px solid {STATUS_HEX[vkind]}; padding:18px 22px;">
        <div class="apex-label" style="color:{COLORS['ink_secondary']};">NEWS IMPACT VERDICT</div>
        <div style="font-size:1.5rem; font-weight:700; color:{STATUS_HEX[vkind]}; margin:4px 0;">{vicon} {vtext}</div>
        <div class="apex-sub" style="color:{COLORS['muted']};">
            Based on {len(relevant_recent)} {ticker}-relevant headline(s) in the last 3 days and {ratio_txt}.
        </div>
    </div>
    """, unsafe_allow_html=True)

    with st.expander("How this verdict is computed"):
        st.markdown(
            "- 🔴 **High**: ≥2 on-topic headlines in the last 3 days *and* today's move is ≥1.5x this ticker's own typical daily range\n"
            "- 🟡 **Moderate**: some relevant coverage or an elevated move, but not both at that threshold\n"
            "- 🟢 **Low**: neither condition met — most likely nothing unusual news-wise right now\n\n"
            "📌 **This is a coincidence flag, not proof of causation** — it says *coverage and price movement line up*, "
            "not *this headline caused that move*. Real sentiment/causal scoring is future work, not this v1."
        )

    st.markdown("##### Supporting detail")
    c1, c2, c3 = st.columns(3)
    with c1:
        vol_kind = "warning" if recent_count >= 5 else "muted" if recent_count <= 1 else "good"
        stat_card("Headline volume (3d)", pill(f"{recent_count} total &middot; {len(relevant_recent)} on-topic", vol_kind))
    with c2:
        if today_move is not None:
            stat_card("Today's move", f"{today_move:+.2f}%", value_color=GOOD if today_move >= 0 else CRITICAL)
        else:
            stat_card("Today's move", "—", sub="Not enough price history")
    with c3:
        if ratio is not None:
            rkind = "serious" if ratio >= 2.5 else "warning" if ratio >= 1.5 else "muted"
            stat_card("Move vs its own 20d-typical", f"{ratio:.1f}x", value_color=STATUS_HEX[rkind],
                       sub=f"typical |move| {typical:.2f}%/day for {ticker} itself")
        else:
            stat_card("Move vs its own 20d-typical", "—")

    if not items:
        st.caption("No headlines returned.")
        return

    st.markdown("##### Headlines")
    rows = []
    for n, pub in dated:
        relevant = is_relevant(n["title"], ticker, company)
        nd, d3, status = np.nan, np.nan, "no price data cached"
        if pub is not None and not price.empty:
            pub_date = pub.normalize()
            before = price[price.index <= pub_date]
            after = price[price.index > pub_date]
            if not before.empty:
                base = before["Close"].iloc[-1]
                if len(after) >= 1:
                    nd = round(float(after["Close"].iloc[0] / base - 1) * 100, 2)
                    status = "computed"
                else:
                    status = "⏳ pending — market hasn't closed since this posted"
                if len(after) >= 3:
                    d3 = round(float(after["Close"].iloc[2] / base - 1) * 100, 2)
        rows.append({
            "Relevant": "✓" if relevant else "", "Headline": n["title"], "Published": n["pub_date"],
            "Next-day %": nd, "3-day %": d3, "Status": status,
        })
    impact_df = pd.DataFrame(rows).sort_values("Relevant", ascending=False)
    relevant_n = sum(1 for r in rows if r["Relevant"] == "✓")
    st.caption(f"{relevant_n} of {len(rows)} headlines actually mention {ticker}/{company} by name — "
               f"the rest are broader market coverage yfinance attaches to this ticker's feed. Sort by "
               f"'Relevant' if you only want the on-topic ones.")
    st.dataframe(
        impact_df, width='stretch', hide_index=True,
        column_config={
            "Next-day %": st.column_config.NumberColumn(format="%.2f%%"),
            "3-day %": st.column_config.NumberColumn(format="%.2f%%"),
        },
    )

    with st.expander(f"All headlines, with links ({len(items)})", expanded=False):
        for n in items:
            title_style = f'color:{COLORS["ink_primary"]};'
            title_html = (f'<a class="apex-news-title" style="{title_style}" href="{n["url"]}" target="_blank">{n["title"]}</a>'
                          if n["url"] else f'<span class="apex-news-title" style="{title_style}">{n["title"]}</span>')
            st.markdown(
                f'<div class="apex-card" style="padding:10px 16px; background:{COLORS["surface"]}; border:1px solid {COLORS["border"]};">{title_html}'
                f'<div class="apex-news-meta" style="color:{COLORS["muted"]};">{n["provider"]} &middot; {n["pub_date"]}</div></div>',
                unsafe_allow_html=True,
            )


# ── MAIN ───────────────────────────────────────────────────────────────────────

def main():
    render_title_theme_and_refresh()
    inject_css()
    render_kpi_strip()
    st.divider()

    tab_score, tab_trend, tab_feed, tab_watch, tab_chart = st.tabs(
        ["Scorecard", "Expectancy Trend", "Signal Feed", "Watchlist", "Ticker Chart & News"])

    with tab_score:
        render_scorecard()
    with tab_trend:
        render_expectancy_trend()
    with tab_feed:
        render_signal_feed()
    with tab_watch:
        render_watchlist()
    with tab_chart:
        tickers = universe()
        if not tickers:
            st.warning("No cached price data in ./data — run Yfinancedata.py first.")
        else:
            # Respects a click from the Watchlist tab (session_state.selected_ticker) if
            # present, otherwise falls back to NVDA or the first available ticker.
            wanted = st.session_state.get("selected_ticker")
            default_ticker = wanted if wanted in tickers else ("NVDA" if "NVDA" in tickers else tickers[0])
            ticker = st.selectbox("Ticker", tickers, index=tickers.index(default_ticker))
            render_ticker_chart(ticker)
            render_news_and_impact(ticker)


if __name__ == "__main__":
    main()
